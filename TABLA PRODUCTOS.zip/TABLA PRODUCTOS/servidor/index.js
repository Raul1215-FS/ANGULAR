const express = require('express')
const conectarDB = require('./config/db')
const cors = require('cors');

//Crea servidor
const app = express();

//Conecta con la BD
conectarDB();
app.use(cors())

//Permite en envio de objetos json a la api
app.use(express.json());

app.use('/api/productos', require('./routes/producto'));

app.listen(4000), () => {
    console.log('El servidor esta corriendo perfectamente')
}