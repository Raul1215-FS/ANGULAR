//Rutas para producto
const express = require('express');
const router = express.Router();
const productoController = require('../controllers/productoController')

//Api productos
router.post('/', productoController.crearProducto);
router.get('/', productoController.obtenerProducto);
router.put('/:id', productoController.actualizaProducto);
router.get('/:id', productoController.obtenerProductoID);
router.delete('/:id', productoController.eliminarProducto);

module.exports = router; 