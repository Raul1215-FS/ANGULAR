1. peticiones hacia backend

2. reutilizar codigo

3. comunicacion de datos entre componentes
