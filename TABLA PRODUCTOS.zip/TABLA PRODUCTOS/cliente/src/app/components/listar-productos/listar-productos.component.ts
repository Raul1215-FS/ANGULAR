import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ProductoService } from '../../services/producto.service';
import { provideHttpClient } from '@angular/common/http';
import { Producto } from '../../models/producto';
import { dateTimestampProvider } from 'rxjs/internal/scheduler/dateTimestampProvider';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-listar-productos',
    standalone: true,
    imports: [RouterModule],
    templateUrl: './listar-productos.component.html',
    styleUrl: './listar-productos.component.css',
})
export class ListarProductosComponent {
    listProductos: Producto[] = [];
    constructor(private _productoService: ProductoService, private toastr: ToastrService) { }

    // ngOnInit(): void {
    //     this.obtenerProductos();
    // }
    ngOnInit() {
        this.obtenerProductos();
    }

    obtenerProductos() {
        this._productoService.getProductos().subscribe(data => {
            this.listProductos = data;
        }, error => {
            console.log(error)
        })
    }

    eliminarProductro(id: any) {
        this._productoService.eliminarProducto(id).subscribe(data => {
            this.toastr.error('El prducto fue eliminado con exito', 'Producto eliminado');
            this.obtenerProductos();
        })
    }
}
