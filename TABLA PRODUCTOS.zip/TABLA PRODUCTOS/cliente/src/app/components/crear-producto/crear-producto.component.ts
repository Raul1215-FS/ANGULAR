import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Producto } from '../../models/producto';
import { ToastrService } from 'ngx-toastr';
import { ProductoService } from '../../services/producto.service';
import { error } from 'console';

@Component({
    selector: 'app-crear-producto',
    standalone: true,
    imports: [RouterModule, CommonModule, ReactiveFormsModule], //CommonModule se importa para usar los elementos como NGIF
    templateUrl: './crear-producto.component.html',
    styleUrl: './crear-producto.component.css',
})
export class CrearProductoComponent {
    productoForm: FormGroup;
    titulo = 'Crear producto';
    id: string | null; // permite NULL

    constructor(private fb: FormBuilder, private router: Router, private _toastr: ToastrService, private _productoService: ProductoService,
        private aRouter: ActivatedRoute //Obtiene el ID de la URL
    ) {
        this.productoForm = this.fb.group({
            producto: ['', Validators.required],
            categoria: ['', Validators.required],
            ubicacion: ['', Validators.required],
            precio: ['', Validators.required],
        });
        this.id = this.aRouter.snapshot.paramMap.get('id');
    }

    ngOnInit(): void {
        this.esEditar();
    }

    agregarProducto() {
        console.log(this.productoForm);

        const PRODUCTO: Producto = {
            nombre: this.productoForm.get('producto')?.value,
            categoria: this.productoForm.get('categoria')?.value,
            ubicacion: this.productoForm.get('ubicacion')?.value,
            precio: this.productoForm.get('precio')?.value,
        }

        if (this.id != null) {
            //Editar prducto
            this._productoService.editarProducto(this.id, PRODUCTO).subscribe(data => {
                this._toastr.info('El producto fue actualizaco con exito!', 'Producto actualizado')
                this.router.navigate(['/'])
            })
        } else {
            //Agregar producto
            this._productoService.guardarProducto(PRODUCTO).subscribe(() => {
                this._toastr.success('El producto fue registrado con exito!', 'Producto registrado')
                this.router.navigate(['/']);
            }, error => {
                console.log(error);
                this.productoForm.reset();
            })
        }
    }

    esEditar() {
        if (this.id != null) {
            this.titulo = 'Editar producto';
            this._productoService.obtenerProducto(this.id).subscribe(data => { //El subscribir es para cuando la funcion llamada devuelve
                // un observable
                this.productoForm.setValue({
                    producto: data.nombre,
                    categoria: data.categoria,
                    ubicacion: data.ubicacion,
                    precio: data.precio
                })
            })
        }
    }
}
